#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
